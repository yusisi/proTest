export default {
  button: [{
    'name': '权游周边',
    'sub_button': [{
      'name': '最新种子',
      'type': 'click',
      'key': 'bt'
    }, {
      'name': '手办商城',
      'type': 'view',
      'key': 'https://iceandfire.iblack7.com/shopping'
    }]
  }, {
    'name': '冰火家族',
    'type': 'view',
    'url': 'https://iceandfire.iblack7.com'
  }, {
     'type': 'miniprogram',
     'name': '权游小程序',
     'url': 'https://iceandfire.iblack7.com',
     'appid': 'wxcac851ec7e9550e2',
     'pagepath': 'pages/index'
 }]
}
